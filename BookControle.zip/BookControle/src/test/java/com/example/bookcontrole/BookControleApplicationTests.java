package com.example.bookcontrole;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookControleApplicationTests {

    @Test
    void contextLoads() {
    }

}
