package com.example.bookcontrole;

import com.example.bookcontrole.entities.Book;
import com.example.bookcontrole.repositories.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;



@SpringBootApplication
public class BookControleApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookControleApplication.class, args);
    }
    @Bean
    CommandLineRunner start(BookRepository bookRepository) {
      return args -> {
        List<Book> books = List.of(Book.builder().titre("Onepiece")
                .publisher("rjhfoiuerh").price("400dh").build(),
                         Book.builder().titre("naruto")
                        .publisher("rjhfoiuerh").price("400dh").build(),
                        Book.builder().titre("dragonball")
                                .publisher("rjhfoiuerh").price("400dh").build());
         bookRepository.saveAll(books);



    };
    }
}
