package com.example.bookcontrole.service;

import com.example.bookcontrole.dto.BookDTO;

import java.util.List;

public interface IBookService {

    BookDTO getBookById(Long id);
    List<BookDTO> getAllBooks();
    BookDTO save( BookDTO bookDTO);
}
