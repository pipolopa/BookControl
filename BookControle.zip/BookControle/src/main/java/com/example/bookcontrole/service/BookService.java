package com.example.bookcontrole.service;

import com.example.bookcontrole.dto.BookDTO;
import com.example.bookcontrole.entities.Book;
import com.example.bookcontrole.mapper.BookMapper;
import com.example.bookcontrole.repositories.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService implements IBookService {

    private final BookRepository bookRepository;
    private final BookMapper bookMapper;

    @Autowired
    public BookService(BookRepository bookRepository, BookMapper bookMapper) {
        this.bookRepository = bookRepository;
        this.bookMapper = bookMapper;
    }

    @Override
    public BookDTO getBookById(Long id) {
        Book book = bookRepository.findById(id).orElse(null);
        return book != null ? bookMapper.toBookDTO(book) : null;
    }

    @Override
    public List<BookDTO> getAllBooks() {
        List<Book> books = bookRepository.findAll();
        return books.stream().map(bookMapper::toBookDTO).collect(Collectors.toList());
    }

    @Override
    public BookDTO save(BookDTO bookDTO) {
        Book book = bookMapper.toBook(bookDTO);


        Book savedBook = bookRepository.save(book);
        return bookMapper.toBookDTO(savedBook);
    }
}
