package com.example.bookcontrole.web;

import com.example.bookcontrole.dto.BookDTO;
import com.example.bookcontrole.service.IBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class BookGraphQlController {
    @Autowired
    private IBookService bookService;


    @QueryMapping
    public List<BookDTO> bookDTOList() {
        return bookService.getAllBooks();
    }

    @QueryMapping
    public BookDTO bookById(@Argument Long id) {
        return bookService.getBookById(id);
    }

    @MutationMapping
    public BookDTO saveVideo(@Argument BookDTO bookDTO) {

        return bookService.save(bookDTO);
    }




}
