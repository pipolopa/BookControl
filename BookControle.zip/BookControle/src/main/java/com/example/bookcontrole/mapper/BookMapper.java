package com.example.bookcontrole.mapper;

import com.example.bookcontrole.dto.BookDTO;
import com.example.bookcontrole.entities.Book;
import org.modelmapper.ModelMapper;

import org.springframework.stereotype.Component;


@Component
public class BookMapper {
    private  ModelMapper modelMapper = new ModelMapper();

    public  BookDTO toBookDTO(Book book) {
        return modelMapper.map(book, BookDTO.class);
    }

    public Book toBook(BookDTO bookDTO) {
        return modelMapper.map(bookDTO, Book.class);
    }

}
