package com.example.bookcontrole.dto;

import lombok.*;

import java.sql.Date;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class BookDTO {
    private String titre;
    private String publisher;
    private Date date_Publication;
    private String price ;
}
